<?php
// Text
$_['text_sign_in_with_google']    = 'Войти';
$_['text_sign_in_with_facebook']    = 'Войти';
$_['text_sign_in_with_twitter']    = 'Войти';
$_['text_sign_in_with_live']    = 'Войти';
$_['text_sign_in_with_linkedin']    = 'Войти';
$_['text_sign_in_with_vkontakte']    = 'Войти';
$_['text_sign_in_with_yandex']    = 'Войти';
$_['text_sign_in_with_odnoklassniki']    = 'Войти';
$_['text_sign_in_with_mailru']    = 'Войти';

$_['button_sign_in']    = 'Войти через';
$_['button_sign_in_mail']    = 'Войти';
$_['text_email']    = 'Введите ваш имейл';
$_['text_firstname']    = 'Введите ваше имя';
$_['text_lastname']    = 'Введите вашу фамилию';
$_['text_phone']    = 'Введите ваш телефон';
$_['text_address_1']    = 'Введите ваш адрес';
$_['text_address_2']    = 'Введите ваш адрес (доп)';
$_['text_city']    = 'Введите ваш город';
$_['text_postcode']    = 'Введите ваш почтовый индекс';
$_['text_country_id']    = 'Выберите страну';
$_['text_zone_id']    = 'Выберите область';
$_['text_password']    = 'Введите ваш пароль';
$_['text_confirm']    = 'Подтвердите ваш пароль';
$_['text_email_intro']    = '<strong>Вы почти готовы.</strong> Пожалуйста, заполните все поля внизу для завершения регистрации. Вы сможете позже их отредактировать на странице вашего аккаунта в магазине.';
$_['error_email_taken']    = 'Ой! этот имейл уже занят.';
$_['error_email_incorrect']    = 'Ой! это не верный имейл.';
$_['error_fill_all_fields']    = 'Ой! Вы должны заполнить все поля.';
$_['error_password_and_confirm_different']    = 'Ой! Ваш пароль не совпадает с паролем введенным для подтверждения.';
?>
